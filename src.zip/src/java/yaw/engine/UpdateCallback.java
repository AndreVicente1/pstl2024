package yaw.engine;

public interface UpdateCallback {
	void update(double deltaTime);
}
