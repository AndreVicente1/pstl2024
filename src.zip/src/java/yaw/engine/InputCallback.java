
package yaw.engine;

public interface InputCallback {
    void sendKey(int key, int scancode, int action, int mods);
}


