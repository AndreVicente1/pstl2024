
// This file is generated from `shadowFragShader.fs` shader program
// Please do not edit directly
package yaw.engine.shader;

public class shadowFragShader {
    public final static String SHADER_STRING = "#version 330\n\nvoid main()\n{\n\n}\n";
}
