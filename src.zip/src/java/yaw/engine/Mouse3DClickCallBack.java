package yaw.engine;

public interface Mouse3DClickCallBack {
    void mouse_click_callback(long window, int button, int action, int mods);

}
