package yaw.engine.mesh;

public interface MeshDrawingStrategy {
    void drawMesh(Mesh pMesh);
}
