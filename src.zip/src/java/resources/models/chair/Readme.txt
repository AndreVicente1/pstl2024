
Chair model (OBJ/MTL
====================

https://sketchfab.com/3d-models/chair-aa2acddb218646a59ece132bf95aa558

----
Copyright CC-BY-SA 4.0 (cf. `legalcode.txt`) by haytonm
(https://sketchfab.com/haytonm)
